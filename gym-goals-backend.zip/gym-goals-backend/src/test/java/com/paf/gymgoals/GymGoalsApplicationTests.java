package com.paf.gymgoals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GymGoalsApplicationTests {

	@Test
	void contextLoads() {
	}

}
