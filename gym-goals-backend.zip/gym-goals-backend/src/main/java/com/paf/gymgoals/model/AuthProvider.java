package com.paf.gymgoals.model;

public enum AuthProvider {
    local,
    facebook,
    google,
}
